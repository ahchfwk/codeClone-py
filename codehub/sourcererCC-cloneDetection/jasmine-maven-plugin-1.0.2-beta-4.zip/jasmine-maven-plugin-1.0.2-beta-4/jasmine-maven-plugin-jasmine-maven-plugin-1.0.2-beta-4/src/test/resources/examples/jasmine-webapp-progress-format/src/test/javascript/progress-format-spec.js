describe('Progress format',function(){
	
	for (var i=0; i < 282; i++) {
		it('should print a dot',function(){});
	};
	
});