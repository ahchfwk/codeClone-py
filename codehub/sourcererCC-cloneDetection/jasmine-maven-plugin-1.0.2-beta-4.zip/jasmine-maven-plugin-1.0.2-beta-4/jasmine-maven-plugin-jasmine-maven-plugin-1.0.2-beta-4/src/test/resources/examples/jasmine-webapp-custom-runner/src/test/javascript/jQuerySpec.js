describe('jQuery',function(){
	
	it('should see that jQuery is defined',function() {
		expect(jQuery).toBeDefined();
	});
	
});