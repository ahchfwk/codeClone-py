var Z = function() {
	this.describe = function() {
		return "the letter Z!";
	}
};