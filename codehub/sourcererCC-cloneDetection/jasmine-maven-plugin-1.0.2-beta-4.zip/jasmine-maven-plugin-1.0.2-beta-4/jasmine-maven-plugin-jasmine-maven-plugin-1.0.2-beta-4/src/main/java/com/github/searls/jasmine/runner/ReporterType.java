package com.github.searls.jasmine.runner;

public enum ReporterType {
	TrivialReporter, JsApiReporter
}