require 'ruby-debug'
require 'nokogiri'

PWD = Dir.pwd